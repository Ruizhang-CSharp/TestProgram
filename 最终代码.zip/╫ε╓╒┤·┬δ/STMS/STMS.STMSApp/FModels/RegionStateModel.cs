﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STMS.STMSApp.FModels
{
    public class RegionStateModel
    {
        public int RegionState { get; set; }
        public string StateText { get; set; }
    }
}
