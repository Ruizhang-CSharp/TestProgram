﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STMS.STMSApp.FModels
{
    public  class FInfoData
    {
        //1 add   2 edit  3  addchild  4 info
         public int ActType { get; set; }
        //主键编号
        public int FId { get; set; }
    }
}
